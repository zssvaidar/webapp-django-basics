from django.apps import AppConfig


class BookstoreManagmentConfig(AppConfig):
    name = 'bookstore_managment'
