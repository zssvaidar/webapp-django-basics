from bookstore.models import   Book, Author, Publisher, Category, bookRibbon, Cart
from django.contrib import admin

admin.site.register(Book)
admin.site.register(Author)
admin.site.register(Publisher)
admin.site.register(Category)
admin.site.register(bookRibbon)
admin.site.register(Cart)
