from django.apps import AppConfig


class InvoiceManagementConfig(AppConfig):
    name = 'invoice_management'
