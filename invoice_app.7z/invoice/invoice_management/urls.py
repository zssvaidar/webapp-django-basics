from django.urls import path
from . import views

urlpatterns = [
    path('invoice/edit/<int:id>', views.edit_invoice_view, name = 'edit_invoice'),
    path('invoice/admin/delete/<int:id>/', views.invoice_delete_view, name = 'invoice_delete'),
    path('invoice/customer/delete/<int:id>/', views.invoice_delete_customer_view, name = 'invoice_delete_customer'),
    path('invoice/add/', views.invoice_add_view, name = 'invoice_add'),
    path('addtocart/<int:item_id>/', views.item_get_view, name = 'item_get'),
]
