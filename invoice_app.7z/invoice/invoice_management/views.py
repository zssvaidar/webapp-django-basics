from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.db import transaction
from .models import iv_items, iv_item_specification, iv_cart, iv_customer
from invoice_profile_management.forms import CartForm
from .forms import ItemForm, SpecificationForm


def invoice_view(request):
        items = iv_items.objects.all()
        specifications = iv_item_specification.objects.all()
        cartform = CartForm()

        context = {
            'goods' : items,
            'specifications' : specifications,
            'cartform' : cartform,
        }

        return render(request, 'invoice_management/invoice_main.html', context)

def item_get_view(request, item_id):

        item_item = iv_items.objects.all().order_by("id")[0]
        item_id = item_id  - item_item.id

        if(request.method == 'POST'):
            cartform = CartForm(request.POST)
            current_user_id = request.user.id
            if(cartform.is_valid()):
                quantitity = cartform.cleaned_data["quantitity"]
                user_fk = iv_customer.objects.get(user = current_user_id)
                item_fk = iv_items.objects.all()[item_id]
                cart = iv_cart(customer_fk = user_fk, item_fk = item_fk, quantitity = quantitity)
                cart.save()
                return redirect ('invoices_page')

        return redirect ('invoices_page')


def edit_invoice_view(request, id):

        if(request.method == 'POST'):
            item = ItemForm(request.POST)
            if(item.is_valid()):
                item.save(commit=False)
                qr = item.cleaned_data["qr"]
                product_name = item.cleaned_data["product_name"]
                quantitity = item.cleaned_data["quantitity"]
                price = item.cleaned_data["price"]
                specification_fk = item.cleaned_data["specification_fk"]
                item_obj = iv_items.objects.all()[id]
                item_obj.qr = qr
                item_obj.product_name = product_name
                item_obj.quantitity = quantitity
                item_obj.price = price
                item_obj.specification_fk = specification_fk
                item_obj.save()
                return redirect('invoices_page')

        item_item = iv_items.objects.all().order_by("id")[0]
        id =  id - item_item.id
        item = ItemForm()
        item.fields['qr'].initial = iv_items.objects.all()[id].qr
        item.fields['product_name'].initial = iv_items.objects.all()[id].product_name
        item.fields['quantitity'].initial = iv_items.objects.all()[id].quantitity
        item.fields['price'].initial = iv_items.objects.all()[id].price
        item.fields['specification_fk'].initial = iv_items.objects.all()[id].specification_fk
        context = {
            'item' : item,
            'id' : id,
            }
        return render(request,'invoice_management/invoice_edit.html',context)
def invoice_add_view(request):
        if(request.method == 'POST'):
            item = ItemForm(request.POST)
            if(item.is_valid()):
                qr = item.cleaned_data["qr"]
                product_name = item.cleaned_data["product_name"]
                quantitity = item.cleaned_data["quantitity"]
                price = item.cleaned_data["price"]
                specification_fk = item.cleaned_data["specification_fk"]
                item_obj = iv_items(qr = qr, product_name = product_name, quantitity = quantitity, price = price, specification_fk = specification_fk)
                item_obj.save()
                return redirect('invoices_page')


        item = ItemForm()
        item.fields['qr'].widget.attrs['placeholder'] = "QR"
        item.fields['product_name'].widget.attrs['placeholder'] = "Product name"
        item.fields['quantitity'].widget.attrs['placeholder'] = "Quantity"
        item.fields['price'].widget.attrs['placeholder'] = "Price"
        context = {
                'item1' : item
            }
        return render(request, 'invoice_management/invoice_edit.html', context )

def invoice_delete_view(request, id):
        dQuery = iv_items.objects.get( id = id).delete()
        return redirect('invoices_page')
def invoice_delete_customer_view(request, id):
        dQuery = iv_cart.objects.get( id = id).delete()
        return redirect('invoice_profile_management:profile')
