from django.apps import AppConfig

class InvoiceProfileManagementConfig(AppConfig):
    name = 'invoice_profile_management'
