from django.urls import path
from . import views_auth, views
urlpatterns = [
    path('profile/', views.profile_view, name = 'profile'),
    path('profile/update/', views_auth.profile_update, name = 'profile_update'),
    path('customer/', views.customer_profile_view, name = 'customer_profile'),
    path('profile/delete/<int:id>/', views.invoice_delete_user_view, name = 'invoice_delete_user'),
]
